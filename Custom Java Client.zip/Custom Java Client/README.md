This is the documentation for Java’s client.

### Compile
To execute compilation, you can use ant to compile `build.xml`.

### Execute
Executable file (.jar) is in `/Java_Client/dist` directory.

```java -jar Java_Client.jar```
